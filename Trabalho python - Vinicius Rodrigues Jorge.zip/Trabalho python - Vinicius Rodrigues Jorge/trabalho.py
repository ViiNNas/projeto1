import json

def carregar_dados():
    try:
        with open('produtos.json', 'r') as arquivo:
            return json.load(arquivo)
    except FileNotFoundError:
        return {}

def salvar_dados(dados):
    with open('produtos.json', 'w') as arquivo:
        json.dump(dados, arquivo, indent=4)

def inserir_produto(dados):
    codigo = input("Digite o código do produto: ")
    if codigo in dados:
        print("Produto com este código já existe.")
        return
    nome = input("Digite o nome do produto: ")
    preco = float(input("Digite o preço do produto: "))
    disponivel = True
    novo_produto = {
        "nome": nome,
        "quantidade": 0, 
        "preco": preco,
        "disponivel": disponivel
    }
    dados[codigo] = novo_produto
    salvar_dados(dados)
    print("Produto adicionado com sucesso!")

def consultar_produto(dados):
    codigo = input("Digite o código do produto: ")
    produto = dados.get(codigo)
    if produto:
        print("Informações do produto:")
        print(f"Código: {codigo}")
        print(f"Nome: {produto['nome']}")
        print(f"Preço: {produto['preco']}")
        print(f"Quantidade disponível: {produto['quantidade']}")
        print(f"Disponível: {'Sim' if produto['disponivel'] else 'Não'}")
    else:
        print("Produto não encontrado.")

def consultar_todos_produtos(dados):
    if dados:
        print("Lista de produtos:")
        for codigo, produto in dados.items():
            print(f"Código: {codigo}, Nome: {produto['nome']}, Preço: {produto['preco']}, Quantidade: {produto['quantidade']}, Disponível: {'Sim' if produto['disponivel'] else 'Não'}")
    else:
        print("Não há produtos cadastrados.")

def alterar_preco(dados):
    codigo = input("Digite o código do produto: ")
    produto = dados.get(codigo)
    if produto:
        novo_preco = float(input("Digite o novo preço: "))
        produto['preco'] = novo_preco
        salvar_dados(dados)
        print("Preço do produto atualizado com sucesso!")
    else:
        print("Produto não encontrado.")

def aplicar_acrescimo_desconto(dados):
    percentual = float(input("Digite o percentual de acréscimo/desconto (positivo para acréscimo, negativo para desconto): "))
    for produto in dados.values():
        produto['preco'] *= (1 + percentual / 100)
    salvar_dados(dados)
    print("Acréscimo/desconto aplicado a todos os produtos com sucesso!")

def excluir_produto(dados):
    codigo = input("Digite o código do produto a ser excluído: ")
    if codigo in dados:
        del dados[codigo]
        salvar_dados(dados)
        print("Produto excluído com sucesso!")
    else:
        print("Produto não encontrado.")

def main():
    dados = carregar_dados()
    
    while True:
        print("\nMenu de Opções:")
        print("1. Inserir um novo produto")
        print("2. Consultar um produto por código")
        print("3. Consultar todos os produtos")
        print("4. Alterar o preço de um determinado produto")
        print("5. Aplicar um acréscimo ou desconto em todos os produtos")
        print("6. Excluir um registro de produto")
        print("7. Sair do programa")
        
        opcao = input("Escolha uma opção: ")
        
        if opcao == '1':
            inserir_produto(dados)
        elif opcao == '2':
            consultar_produto(dados)
        elif opcao == '3':
            consultar_todos_produtos(dados)
        elif opcao == '4':
            alterar_preco(dados)
        elif opcao == '5':
            aplicar_acrescimo_desconto(dados)
        elif opcao == '6':
            excluir_produto(dados)
        elif opcao == '7':
            salvar_dados(dados)
            print("Programa encerrado.")
            break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    main()
